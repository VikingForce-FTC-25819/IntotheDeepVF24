## Vibranium Viking Team Info

Creation of documentation regarding how our code "flows"

All devices start with methods in the vvHardware.java class

Using 'robot.' can call any hardware from that class in the active class for reuse and ease

1Nov23 Programming objectives - Video the team prop and begin the ML process.  Read the Road Runner code and begin to implement in preparation of tuning.

5Nov23 Added new Packages to keep things tidy.
 - Auton, Concept, Core, & TeleOp
 - Core is for any classes we intent to call for methods and actions
 - Concept will be any troubleshooting or learning classes

14Nov23 Adjusted to a right claw, taller arm gear ratio, and new start position (arm up with pickup collapsed)
- Classes impacted, vvHardware, new TeleOp for testing
- Added Field Centric method to vvHardware